### websocket demo
#### 说明
此demo使用spring boot框架，基于内嵌的tomcat，使用rabbitmq作为后端消息代理实现websocket功能。  
客户端可以使用html5实现，在不支持html5的情况下，可以使用sockjs实现websocket。  
rabbitmq已经实现了心跳、消息ACK、消息持久化等功能，只需要在此框架下填写业务代码即可。  
此demo使用stomp协议实现消息点对点传输和发布订阅功能，客户端可以使用支持stomp协议的框架和服务端进行交互。  

#### demo启动入口
运行`WebsocketDemoApplication`中的`main`方法启动demo，在rabbitmq配置无误的情况下，应正常启动（可能需要修改日志文件的路径）。  
启动完成后，访问`http://localhost:9000`，打开测试页面。  
点击**connect**按钮，建立websocket连接。在输入框输入消息内容，点击**send**发送消息。  

#### 代码说明
点击**send**之后，此消息被`DemoController`中的`@MessageMapping("/test")`拦截，并使用`SimpMessagingTemplate`向客户端回复消息。  
还可以通过http请求，在浏览器中访问`http://localhost:9000/send?userId=1234&message=aaa`，调用`DemoController`中的`sendMessage`方法，向客户端发送消息。  
不同环境可以使用不同的`virtual-host`，避免消息干扰，达到环境隔离的目的。比如：本地环境使用`local-host`，测试环境使用`test-host`，验收环境使用`check-host`。  

#### rabbitmq部署（运维关注）
先安装erlang环境，再安装rabbitmq。安装期间可能需要安装其他依赖包，比如：socat等。  
安装完成后，启动rabbitmq server : `/sbin/service rabbitmq-server start`  
启动管理后台插件 : `rabbitmq-plugins enable rabbitmq_management`  
允许管理后台远程登录 : `vim /etc/rabbitmq/rabbitmq.config`, 增加`[{rabbit, [{loopback_users, []}]}].`。  
启动websocket插件 : `rabbitmq-plugins enable rabbitmq_web_stomp`  
访问管理后台 : `http://172.18.171.25:15672/`，用户名密码:`guest/guest`

#### rabbitmq集群（运维关注）
1. 在另一台机器上用同样的步骤安装rabbitmq，配置两台机器的hosts，使两台机器通过hostname可以互相访问。  
2. 查看集群状态 : `rabbitmqctl cluster_status`  
停止从节点 : `rabbitmqctl stop_app`  
3. 复制主节点的erlang cookie值 : `vim /var/lib/rabbitmq/.erlang.cookie`  
4. 在从节点写入刚复制的erlang cookie值，增加写权限 : `chmod +w /var/lib/rabbitmq/.erlang.cookie`，保存之后还原权限 : `chmod 400 /var/lib/rabbitmq/.erlang.cookie`
5. 从节点加入集群 : `rabbitmqctl join_cluster 主节点名称`
6. 启动从节点 : `rabbitmqctl start_app`  

**注意：重写erlang cookie后需要重启rabbitmq，通过kill -9 杀掉所有rabbit相关进程**  

集群策略使用镜像队列，把队列数据复制到集群中的每一台机器，实现高可用。  
如果集群中的机器数量过多，可以只在一部分节点设置镜像队列，减少集群间复制数据的性能损耗。  
在消息允许部分丢失的情况下，可以设置集群中的部分节点为内存节点，减少消息持久化的磁盘IO损耗。  

可以使用nginx或F5做负载均衡，nginx配置如下： 
````
stream {
  upstream stomp_backend {
    server ip:61613 max_fails=3 fail_timeout=10s;
    server ip:61613 max_fails=3 fail_timeout=10s;
  }

  upstream amqp_backend {
    server ip:5672 max_fails=3 fail_timeout=10s;
    server ip:5672 max_fails=3 fail_timeout=10s;
  }

  server {
    listen 61613;
    proxy_connect_timeout 10s;
    proxy_timeout 10m;
    proxy_pass stomp_backend;
  }

  server {
    listen 5672;
    proxy_connect_timeout 10s;
    proxy_timeout 10m;
    proxy_pass amqp_backend;
  }
}
````  
需要对5672和61613两个端口做负载均衡，5672端口用于amqp协议的消息交互，61613端口用于stomp协议的消息交互

